import Canvas from "./Editor/Canvas";

function Workflowsapp() {
  return (
    <>
    <div>
      <Canvas></Canvas>
    </div>
    </>
  );
}

export default Workflowsapp;
