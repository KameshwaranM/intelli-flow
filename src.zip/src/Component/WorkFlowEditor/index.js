import React from 'react';
import ReactDOM from 'react-dom';
import Workflowsapp from './App';

ReactDOM.render(
  <React.StrictMode>
    <Workflowsapp />
  </React.StrictMode>,
  document.getElementById('root')
);