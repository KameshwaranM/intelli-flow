const BASE_URL = 'http://127.0.0.1:8985';
export default BASE_URL;