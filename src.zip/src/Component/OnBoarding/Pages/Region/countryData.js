export const countryData = [
  { id: 1, name: "United States" },
  { id: 2, name: "Asia" },
  { id: 3, name: "Europe" }
];