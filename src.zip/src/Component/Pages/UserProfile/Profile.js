import React from 'react';
import SidebarMenu from '../../Sidebar/Sidebar';

function UserProfile() {
  return (
    <>
    <div>
      <SidebarMenu />
      <div>
      
      </div>
    </div>
    </>
  );
}

export default UserProfile;