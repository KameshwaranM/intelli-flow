import React from 'react';

function ProfileRestPWD() {
  return (
    <>
    <div>
      <SidebarMenu />
      <div>
     
      </div>
    </div>
    </>
  );
}

export default ProfileRestPWD;