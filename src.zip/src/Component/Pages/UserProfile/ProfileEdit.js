import React from 'react';
import SidebarMenu from '../../Sidebar/Sidebar';


function ProfileEdit() {
  return (
    <>
    <div>
      <SidebarMenu />
      <div>
      
      </div>
    </div>
    </>
  );
}

export default ProfileEdit;